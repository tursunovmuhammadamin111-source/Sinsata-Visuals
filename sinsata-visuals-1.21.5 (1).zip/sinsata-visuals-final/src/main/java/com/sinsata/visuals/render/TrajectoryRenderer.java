package com.sinsata.visuals.render;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.*;
import net.minecraft.entity.thrown.*;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import java.util.*;
public class TrajectoryRenderer {
    public static void render(MatrixStack ms, Camera cam, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world==null||mc.player==null) return;
        var cfg = SinsataVisuals.config;
        Vec3d c = cam.getPos();
        var imm = mc.getBufferBuilders().getEntityVertexConsumers();
        for (Entity e : mc.world.getEntities()) {
            boolean mine = e.getOwner()==mc.player;
            boolean other = !mine && cfg.trajectoryOtherPlayers;
            if (!mine&&!other) continue;
            double g; boolean ok=false;
            if      (e instanceof ArrowEntity     && cfg.trajectoryBow)         { g=0.05; ok=true; }
            else if (e instanceof TridentEntity   && cfg.trajectoryTrident)     { g=0.05; ok=true; }
            else if (e instanceof EnderPearlEntity && cfg.trajectoryEnderPearl) { g=0.03; ok=true; }
            else if (e instanceof SnowballEntity  && cfg.trajectorySnowball)    { g=0.03; ok=true; }
            else if (e instanceof PotionEntity    && cfg.trajectoryPotion)      { g=0.03; ok=true; }
            else g=0.05;
            if (!ok) continue;
            List<Vec3d> pts = sim(e.getLerpedPos(delta), e.getVelocity(), g, cfg.trajectoryLength);
            float[] col = hex(cfg.trajectoryColor);
            drawPath(ms,imm,pts,c,col);
            if (cfg.trajectoryEndMarker&&!pts.isEmpty()) drawMark(ms,imm,pts.get(pts.size()-1),c,col);
        }
        imm.draw();
    }
    private static List<Vec3d> sim(Vec3d p, Vec3d v, double g, int n) {
        List<Vec3d> l=new ArrayList<>();
        double x=p.x,y=p.y,z=p.z,vx=v.x,vy=v.y,vz=v.z;
        l.add(new Vec3d(x,y,z));
        for(int i=0;i<n;i++){vx*=0.99;vy-=g;vy*=0.99;vz*=0.99;x+=vx;y+=vy;z+=vz;l.add(new Vec3d(x,y,z));if(y<-64)break;}
        return l;
    }
    private static void drawPath(MatrixStack ms,VertexConsumerProvider.Immediate imm,List<Vec3d> pts,Vec3d c,float[] col) {
        if(pts.size()<2)return;
        var vc=imm.getBuffer(RenderLayer.getLines());
        Matrix4f m=ms.peek().getPositionMatrix();
        for(int i=0;i<pts.size()-1;i++){
            Vec3d a=pts.get(i),b=pts.get(i+1);
            float ax=(float)(a.x-c.x),ay=(float)(a.y-c.y),az=(float)(a.z-c.z);
            float bx=(float)(b.x-c.x),by=(float)(b.y-c.y),bz=(float)(b.z-c.z);
            float nx=bx-ax,ny=by-ay,nz=bz-az,len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
            if(len>0){nx/=len;ny/=len;nz/=len;}
            vc.vertex(m,ax,ay,az).color(col[0],col[1],col[2],col[3]).normal(nx,ny,nz);
            vc.vertex(m,bx,by,bz).color(col[0],col[1],col[2],col[3]).normal(nx,ny,nz);
        }
    }
    private static void drawMark(MatrixStack ms,VertexConsumerProvider.Immediate imm,Vec3d pos,Vec3d c,float[] col) {
        float s=0.2f,px=(float)(pos.x-c.x),py=(float)(pos.y-c.y),pz=(float)(pos.z-c.z);
        var vc=imm.getBuffer(RenderLayer.getLines()); Matrix4f m=ms.peek().getPositionMatrix();
        vc.vertex(m,px-s,py,pz).color(col[0],col[1],col[2],1f).normal(1,0,0);
        vc.vertex(m,px+s,py,pz).color(col[0],col[1],col[2],1f).normal(1,0,0);
        vc.vertex(m,px,py-s,pz).color(col[0],col[1],col[2],1f).normal(0,1,0);
        vc.vertex(m,px,py+s,pz).color(col[0],col[1],col[2],1f).normal(0,1,0);
        vc.vertex(m,px,py,pz-s).color(col[0],col[1],col[2],1f).normal(0,0,1);
        vc.vertex(m,px,py,pz+s).color(col[0],col[1],col[2],1f).normal(0,0,1);
    }
    private static float[] hex(int h){return new float[]{((h>>16)&0xFF)/255f,((h>>8)&0xFF)/255f,(h&0xFF)/255f,0.9f};}
}
