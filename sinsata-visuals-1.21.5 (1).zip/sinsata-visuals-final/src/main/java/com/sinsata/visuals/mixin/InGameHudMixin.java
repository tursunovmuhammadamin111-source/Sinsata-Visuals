package com.sinsata.visuals.mixin;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method="renderCrosshair",at=@At("HEAD"),cancellable=true)
    private void cancelCrosshair(DrawContext ctx,CallbackInfo ci){
        if(SinsataVisuals.config!=null&&SinsataVisuals.config.customCrosshair) ci.cancel();
    }
    @Inject(method="renderStatusBars",at=@At("HEAD"),cancellable=true)
    private void cancelHealth(DrawContext ctx,CallbackInfo ci){
        if(SinsataVisuals.config!=null&&SinsataVisuals.config.showHealth) ci.cancel();
    }
    @Inject(method="renderOverlay",at=@At("HEAD"),cancellable=true)
    private void cancelHelmet(DrawContext ctx,float f,CallbackInfo ci){
        if(SinsataVisuals.config!=null&&!SinsataVisuals.config.showHelmet) ci.cancel();
    }
}
