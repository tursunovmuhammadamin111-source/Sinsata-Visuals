package com.sinsata.visuals.mixin;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyReturnValue;
@Mixin(value=GameRenderer.class,priority=900)
public class GameRendererMixin {
    @ModifyReturnValue(method="getFov",at=@At("RETURN"))
    private double modFov(double orig){
        if(SinsataVisuals.config!=null&&SinsataVisuals.config.customFov) return SinsataVisuals.config.fov;
        return orig;
    }
}
