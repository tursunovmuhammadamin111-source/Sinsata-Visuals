package com.sinsata.visuals.config;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.Path;
public class SinsataConfig {
    private static final Gson G = new GsonBuilder().setPrettyPrinting().create();
    private static final Path P = FabricLoader.getInstance().getConfigDir().resolve("sinsata-visuals.json");
    public boolean hudEnabled=true; public boolean showHealth=true; public boolean healthOnLeft=true;
    public boolean showPing=true; public boolean showFps=true; public float hudScale=1f;
    public boolean showArmor=true; public boolean showCoords=true; public boolean showEffects=true;
    public boolean showHelmet=false;
    public boolean customCrosshair=true; public int crosshairType=0; public int crosshairSize=8;
    public int crosshairThick=2; public int crosshairColor=0xFFFFFF; public boolean showJumpCircle=true;
    public boolean fullbrightEnabled=true; public float gamma=16f;
    public boolean hitboxEnabled=true; public boolean hitboxPlayers=true; public boolean hitboxMobs=false;
    public int hitboxEnemyColor=0xFF4444; public int hitboxFriendColor=0x44FF88;
    public float hitboxOpacity=0.8f; public int hitboxRange=32; public boolean showPlayerTag=true;
    public boolean particlesEnabled=true; public int particleCount=60; public float particleSpeed=4f;
    public float particleSize=1f; public int particleColor=0xFF4444;
    public boolean hitEffectEnabled=true; public boolean blockBreakEffect=true; public int blockBreakIntensity=7;
    public boolean trajectoryEnabled=true; public boolean trajectoryOtherPlayers=true;
    public boolean trajectoryTrident=true; public boolean trajectoryBow=true;
    public boolean trajectoryEnderPearl=true; public boolean trajectorySnowball=false;
    public boolean trajectoryPotion=true; public int trajectoryColor=0xFF4444;
    public int trajectoryLength=30; public boolean trajectoryEndMarker=true;
    public boolean showHand=true; public boolean leftHand=false;
    public float handX=0f; public float handY=0f; public float handZ=0f; public float handTilt=0f;
    public boolean freecamEnabled=false; public boolean customFov=false;
    public float fov=90f; public boolean noViewBob=false;
    public boolean fogEnabled=false; public float fogDensity=0f;
    public boolean rainEnabled=true; public boolean snowEnabled=true;
    public boolean blockOverlayEnabled=true; public boolean showBlockCoords=true;
    public boolean showBlockId=false; public float blockOutlineWidth=1f; public boolean blockBreakOverlay=true;
    public boolean autoSprint=true; public boolean noHurtCam=true;
    public boolean tracesEnabled=false; public int tracesLength=20; public int tracesColor=0xFF4444;
    public static SinsataConfig load() {
        if (P.toFile().exists()) {
            try (Reader r=new FileReader(P.toFile())) { SinsataConfig c=G.fromJson(r,SinsataConfig.class); return c!=null?c:new SinsataConfig(); }
            catch (Exception e) { return new SinsataConfig(); }
        }
        SinsataConfig c=new SinsataConfig(); c.save(); return c;
    }
    public void save() { try (Writer w=new FileWriter(P.toFile())) { G.toJson(this,w); } catch (Exception ignored) {} }
}
