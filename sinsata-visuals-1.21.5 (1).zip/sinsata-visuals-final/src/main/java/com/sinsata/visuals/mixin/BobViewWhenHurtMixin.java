package com.sinsata.visuals.mixin;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=GameRenderer.class,priority=900)
public class BobViewWhenHurtMixin {
    @Inject(method="bobViewWhenHurt",at=@At("HEAD"),cancellable=true)
    private void noHurt(MatrixStack ms,float delta,CallbackInfo ci){
        if(SinsataVisuals.config!=null&&SinsataVisuals.config.noHurtCam) ci.cancel();
    }
}
