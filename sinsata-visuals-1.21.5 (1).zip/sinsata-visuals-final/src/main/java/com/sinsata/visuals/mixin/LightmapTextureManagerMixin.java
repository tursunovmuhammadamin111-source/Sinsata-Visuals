package com.sinsata.visuals.mixin;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @ModifyVariable(method="update",at=@At("STORE"),ordinal=0)
    private float modifyGamma(float gamma) {
        if(SinsataVisuals.config!=null&&SinsataVisuals.config.fullbrightEnabled) return SinsataVisuals.config.gamma;
        return gamma;
    }
}
