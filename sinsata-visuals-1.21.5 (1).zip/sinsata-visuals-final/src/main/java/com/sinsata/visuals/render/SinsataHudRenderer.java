package com.sinsata.visuals.render;
import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
public class SinsataHudRenderer {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    public void render(DrawContext ctx, float delta) {
        SinsataConfig cfg = SinsataVisuals.config;
        if (!cfg.hudEnabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        ClientPlayerEntity pl = mc.player;
        TextRenderer font = mc.textRenderer;
        int W = mc.getWindow().getScaledWidth();
        int H = mc.getWindow().getScaledHeight();
        if (cfg.showHealth)              renderHealth(ctx,font,pl,cfg,W,H);
        if (cfg.showPing||cfg.showFps)   renderInfo(ctx,font,pl,cfg,W);
        if (cfg.showCoords)              renderCoords(ctx,font,pl,W);
        if (cfg.showArmor)               renderArmor(ctx,font,pl,cfg,W,H);
        if (cfg.customCrosshair)         renderCrosshair(ctx,cfg,W,H,pl);
        if (cfg.showEffects)             renderEffects(ctx,font,pl,W);
    }
    private void renderHealth(DrawContext ctx,TextRenderer font,ClientPlayerEntity pl,SinsataConfig cfg,int W,int H){
        float hp=pl.getHealth(), max=pl.getMaxHealth(), pct=max>0?hp/max:0;
        int col = pct>0.6f?0xFF44FF88:pct>0.3f?0xFFFFAA00:0xFFFF4444;
        int pX=cfg.healthOnLeft?4:W-84, pY=H-54, pW=80, pH=26;
        ctx.fill(pX,pY,pX+pW,pY+pH,0xCC080810);
        ctx.fill(pX,pY,pX+2,pY+pH,col);
        ctx.fill(pX+2,pY,pX+pW,pY+1,0x33FFFFFF);
        int bX=pX+6,bY=pY+5,bW=pW-12,bH=5;
        ctx.fill(bX,bY,bX+bW,bY+bH,0x33FFFFFF);
        int fw=(int)(bW*pct); if(fw>0) ctx.fill(bX,bY,bX+fw,bY+bH,col);
        ctx.drawText(font,"\u2665 "+String.format("%.1f",hp)+"/"+(int)max,pX+6,pY+14,col,true);
    }
    private void renderInfo(DrawContext ctx,TextRenderer font,ClientPlayerEntity pl,SinsataConfig cfg,int W){
        int x=W-4,y=4;
        if(cfg.showFps){
            int fps=MinecraftClient.getCurrentFps();
            int c=fps>=100?0xFF44FF88:fps>=60?0xFFFFAA00:0xFFFF4444;
            String s=fps+" FPS"; renderTag(ctx,font,s,x-font.getWidth(s)-2,y,c); y+=13;
        }
        if(cfg.showPing){
            int ping=0; var nh=mc.getNetworkHandler();
            if(nh!=null){PlayerListEntry e=nh.getPlayerListEntry(pl.getUuid());if(e!=null)ping=e.getLatency();}
            int c=ping<60?0xFF44FF88:ping<150?0xFFFFAA00:0xFFFF4444;
            String s=ping+" ms"; renderTag(ctx,font,s,x-font.getWidth(s)-2,y,c);
        }
    }
    private void renderTag(DrawContext ctx,TextRenderer font,String t,int x,int y,int col){
        int w=font.getWidth(t)+6;
        ctx.fill(x-1,y-1,x+w+1,y+10,0xAA080810);
        ctx.fill(x-1,y-1,x,y+10,col);
        ctx.drawText(font,t,x+3,y,col,false);
    }
    private void renderCoords(DrawContext ctx,TextRenderer font,ClientPlayerEntity pl,int W){
        String s=String.format("X:%d  Y:%d  Z:%d",(int)pl.getX(),(int)pl.getY(),(int)pl.getZ());
        int cx=W/2-font.getWidth(s)/2;
        ctx.fill(cx-4,2,cx+font.getWidth(s)+4,14,0xAA080810);
        ctx.drawText(font,s,cx,4,0xAAAAEEFF,false);
    }
    private void renderArmor(DrawContext ctx,TextRenderer font,ClientPlayerEntity pl,SinsataConfig cfg,int W,int H){
        int a=pl.getArmor(); if(a<=0)return;
        int pX=cfg.healthOnLeft?4:W-84;
        ctx.drawText(font,"\u26E1 "+a,pX+6,H-26,0xFF8899AA,true);
    }
    private void renderCrosshair(DrawContext ctx,SinsataConfig cfg,int W,int H,ClientPlayerEntity pl){
        int cx=W/2,cy=H/2,col=0xFF000000|cfg.crosshairColor,sz=cfg.crosshairSize,th=cfg.crosshairThick;
        switch(cfg.crosshairType){
            case 0->{ ctx.fill(cx-sz,cy-th/2,cx+sz,cy+th/2+1,col); ctx.fill(cx-th/2,cy-sz,cx+th/2+1,cy+sz,col); }
            case 1->  ctx.fill(cx-2,cy-2,cx+2,cy+2,col);
            case 2->  drawCircle(ctx,cx,cy,sz,1,col);
            case 3->{ ctx.fill(cx-sz,cy-th/2,cx+sz,cy+th/2+1,col); ctx.fill(cx-th/2,cy,cx+th/2+1,cy+sz,col); }
        }
        if(cfg.showJumpCircle&&pl.isOnGround()) drawCircle(ctx,cx,cy,sz+7,1,col&0x55FFFFFF);
    }
    private void drawCircle(DrawContext ctx,int cx,int cy,int r,int th,int col){
        int steps=36;
        for(int i=0;i<steps;i++){
            double a1=2*Math.PI*i/steps,a2=2*Math.PI*(i+1)/steps;
            int x1=cx+(int)(Math.cos(a1)*r),y1=cy+(int)(Math.sin(a1)*r);
            int x2=cx+(int)(Math.cos(a2)*r),y2=cy+(int)(Math.sin(a2)*r);
            ctx.fill(Math.min(x1,x2),Math.min(y1,y2),Math.max(x1,x2)+th,Math.max(y1,y2)+th,col);
        }
    }
    private void renderEffects(DrawContext ctx,TextRenderer font,ClientPlayerEntity pl,int W){
        var effects=pl.getStatusEffects(); if(effects.isEmpty())return;
        int ey=62;
        for(var eff:effects){
            int d=eff.getDuration();
            String dur=d>32000?"inf":String.format("%d:%02d",d/1200,(d%1200)/20);
            String line=eff.getEffectType().value().getName().getString()+" "+dur;
            int col=eff.getEffectType().value().getColor()|0xFF000000;
            renderTag(ctx,font,line,W-font.getWidth(line)-8,ey,col); ey+=13;
        }
    }
}
