package com.sinsata.visuals.mixin;
import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.render.HitboxRenderer;
import com.sinsata.visuals.render.TrajectoryRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    @Inject(method="render",at=@At("TAIL"))
    private void onRender(RenderTickCounter counter,boolean renderBlockOutline,Camera camera,
            GameRenderer gameRenderer,LightmapTextureManager light,Matrix4f proj,CallbackInfo ci){
        if(SinsataVisuals.config==null) return;
        MatrixStack ms=new MatrixStack();
        if(SinsataVisuals.config.hitboxEnabled) HitboxRenderer.render(ms,camera,counter.getTickDelta(true));
        if(SinsataVisuals.config.trajectoryEnabled) TrajectoryRenderer.render(ms,camera,counter.getTickDelta(true));
    }
}
