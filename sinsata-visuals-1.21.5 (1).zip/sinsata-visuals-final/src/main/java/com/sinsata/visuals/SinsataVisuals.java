package com.sinsata.visuals;
import com.sinsata.visuals.config.SinsataConfig;
import com.sinsata.visuals.gui.SinsataGuiScreen;
import com.sinsata.visuals.module.ModuleManager;
import com.sinsata.visuals.render.SinsataHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.IdentifiedLayer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class SinsataVisuals implements ClientModInitializer {
    public static final String MOD_ID = "sinsata-visuals";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static SinsataConfig config;
    public static ModuleManager moduleManager;
    public static SinsataHudRenderer hudRenderer;
    public static KeyBinding openGuiKey, hitboxKey, particlesKey, fullbrightKey, trajectoryKey;
    @Override
    public void onInitializeClient() {
        LOGGER.info("[SinsataVisuals] Yuklanmoqda - 1.21.5");
        config = SinsataConfig.load();
        moduleManager = new ModuleManager();
        hudRenderer = new SinsataHudRenderer();
        openGuiKey      = reg("open_gui",    GLFW.GLFW_KEY_RIGHT_SHIFT);
        hitboxKey       = reg("hitbox",      GLFW.GLFW_KEY_H);
        particlesKey    = reg("particles",   GLFW.GLFW_KEY_P);
        fullbrightKey   = reg("fullbright",  GLFW.GLFW_KEY_F5);
        trajectoryKey   = reg("trajectory",  GLFW.GLFW_KEY_F6);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            moduleManager.onTick(client);
            if (openGuiKey.wasPressed())   client.setScreen(new SinsataGuiScreen());
            if (hitboxKey.wasPressed())    { config.hitboxEnabled      = !config.hitboxEnabled;      config.save(); }
            if (particlesKey.wasPressed()) { config.particlesEnabled   = !config.particlesEnabled;   config.save(); }
            if (fullbrightKey.wasPressed()){ config.fullbrightEnabled  = !config.fullbrightEnabled;  config.save(); }
            if (trajectoryKey.wasPressed()){ config.trajectoryEnabled  = !config.trajectoryEnabled;  config.save(); }
        });
        // 1.21.5: HudLayerRegistrationCallback ishlatiladi
        HudLayerRegistrationCallback.EVENT.register(layers ->
            layers.addAfter(IdentifiedLayer.STATUS_EFFECTS,
                Identifier.of(MOD_ID, "hud"),
                (drawContext, renderTickCounter) ->
                    hudRenderer.render(drawContext, renderTickCounter.getTickDelta(true))
            )
        );
        LOGGER.info("[SinsataVisuals] Tayyor!");
    }
    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.sinsata-visuals." + name, InputUtil.Type.KEYSYM, key, "category.sinsata-visuals"));
    }
}
