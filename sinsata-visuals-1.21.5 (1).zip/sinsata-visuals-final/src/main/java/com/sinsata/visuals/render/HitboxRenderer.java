package com.sinsata.visuals.render;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public class HitboxRenderer {
    public static void render(MatrixStack ms, Camera cam, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world==null||mc.player==null) return;
        var cfg = SinsataVisuals.config;
        Vec3d c = cam.getPos();
        var imm = mc.getBufferBuilders().getEntityVertexConsumers();
        for (Entity e : mc.world.getEntities()) {
            if (e==mc.player) continue;
            boolean isP = e instanceof PlayerEntity && cfg.hitboxPlayers;
            boolean isM = e instanceof HostileEntity && cfg.hitboxMobs;
            if (!isP&&!isM) continue;
            if (mc.player.distanceTo(e)>cfg.hitboxRange) continue;
            Vec3d lp = e.getLerpedPos(delta);
            Box box = e.getBoundingBox().offset(lp.negate());
            float[] col = isP ? hex(cfg.hitboxEnemyColor,cfg.hitboxOpacity) : hex(cfg.hitboxFriendColor,cfg.hitboxOpacity);
            ms.push();
            ms.translate(lp.x-c.x, lp.y-c.y, lp.z-c.z);
            drawBox(ms.peek().getPositionMatrix(), imm.getBuffer(RenderLayer.getLines()),
                (float)box.minX,(float)box.minY,(float)box.minZ,
                (float)box.maxX,(float)box.maxY,(float)box.maxZ, col);
            ms.pop();
        }
        imm.draw();
    }
    private static void drawBox(Matrix4f m, VertexConsumer vc,
            float x1,float y1,float z1,float x2,float y2,float z2,float[] col) {
        ln(m,vc,x1,y1,z1,x2,y1,z1,col); ln(m,vc,x2,y1,z1,x2,y1,z2,col);
        ln(m,vc,x2,y1,z2,x1,y1,z2,col); ln(m,vc,x1,y1,z2,x1,y1,z1,col);
        ln(m,vc,x1,y2,z1,x2,y2,z1,col); ln(m,vc,x2,y2,z1,x2,y2,z2,col);
        ln(m,vc,x2,y2,z2,x1,y2,z2,col); ln(m,vc,x1,y2,z2,x1,y2,z1,col);
        ln(m,vc,x1,y1,z1,x1,y2,z1,col); ln(m,vc,x2,y1,z1,x2,y2,z1,col);
        ln(m,vc,x2,y1,z2,x2,y2,z2,col); ln(m,vc,x1,y1,z2,x1,y2,z2,col);
    }
    private static void ln(Matrix4f m,VertexConsumer vc,float ax,float ay,float az,float bx,float by,float bz,float[] c) {
        float nx=bx-ax,ny=by-ay,nz=bz-az,len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len>0){nx/=len;ny/=len;nz/=len;}
        vc.vertex(m,ax,ay,az).color(c[0],c[1],c[2],c[3]).normal(nx,ny,nz);
        vc.vertex(m,bx,by,bz).color(c[0],c[1],c[2],c[3]).normal(nx,ny,nz);
    }
    private static float[] hex(int h,float a){return new float[]{((h>>16)&0xFF)/255f,((h>>8)&0xFF)/255f,(h&0xFF)/255f,a};}
}
