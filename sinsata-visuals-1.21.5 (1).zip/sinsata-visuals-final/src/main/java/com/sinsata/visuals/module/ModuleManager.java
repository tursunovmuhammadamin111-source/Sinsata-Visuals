package com.sinsata.visuals.module;
import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.MinecraftClient;
public class ModuleManager {
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        if (SinsataVisuals.config.autoSprint) {
            if (client.player.input != null && client.player.input.movementForward > 0
                    && !client.player.isSneaking()) {
                client.player.setSprinting(true);
            }
        }
    }
}
