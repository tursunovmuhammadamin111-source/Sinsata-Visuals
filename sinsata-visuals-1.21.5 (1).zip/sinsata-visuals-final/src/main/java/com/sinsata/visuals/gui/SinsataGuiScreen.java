package com.sinsata.visuals.gui;
import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.*;
import java.util.function.*;
public class SinsataGuiScreen extends Screen {
    private static final int BG=0xF0080810,PANEL=0xFF0E0E16,RED=0xFFFF3333,MUTED=0xFF666677,TEXT=0xFFDDDDDD,ON=0xFFFF3333,OFF=0xFF252535,SBG=0xFF1A1A28,SFG=0xFFFF3333,HOV=0xFF141422;
    private static final int GW=490,GH=310,HH=22,TH=18,EH=20,GAP=6;
    private static final String[] TABS={"HUD","HITBOX","ZARRALAR","BASHORAT","DUNYO","QO'L","BLOQLAR"};
    private int gX,gY,tab=0;
    private final List<Object> els=new ArrayList<>();
    private int scrollY=0,drag=-1;
    public SinsataGuiScreen(){super(Text.literal("Sinsata Visuals"));}
    @Override protected void init(){gX=(width-GW)/2;gY=(height-GH)/2;rebuild();}
    private void rebuild(){els.clear();scrollY=0;SinsataConfig c=SinsataVisuals.config;
        switch(tab){
        case 0->{sec("ASOSIY");tog("HUD faol",()->c.hudEnabled,v->c.hudEnabled=v);tog("Hayot",()->c.showHealth,v->c.showHealth=v);tog("Chapda",()->c.healthOnLeft,v->c.healthOnLeft=v);tog("Armor",()->c.showArmor,v->c.showArmor=v);tog("Koordinatalar",()->c.showCoords,v->c.showCoords=v);tog("Ping",()->c.showPing,v->c.showPing=v);tog("FPS",()->c.showFps,v->c.showFps=v);tog("Effectlar",()->c.showEffects,v->c.showEffects=v);tog("Bosh kiyim",()->c.showHelmet,v->c.showHelmet=v);sec("NISHON");tog("Custom nishon",()->c.customCrosshair,v->c.customCrosshair=v);sld("O'lcham",2,20,()->(float)c.crosshairSize,v->c.crosshairSize=(int)v);sld("Qalinlik",1,5,()->(float)c.crosshairThick,v->c.crosshairThick=(int)v);tog("Sakrash doirasi",()->c.showJumpCircle,v->c.showJumpCircle=v);sec("YORUG'LIK");tog("To'liq yorug'lik",()->c.fullbrightEnabled,v->c.fullbrightEnabled=v);sld("Gamma",1,32,()->c.gamma,v->c.gamma=v);sec("BOSHQA");tog("No hurtcam",()->c.noHurtCam,v->c.noHurtCam=v);tog("Auto sprint",()->c.autoSprint,v->c.autoSprint=v);tog("Izlar",()->c.tracesEnabled,v->c.tracesEnabled=v);sld("Izlar uzunligi",5,60,()->(float)c.tracesLength,v->c.tracesLength=(int)v);}
        case 1->{sec("HITBOX");tog("Faol",()->c.hitboxEnabled,v->c.hitboxEnabled=v);tog("O'yinchilar",()->c.hitboxPlayers,v->c.hitboxPlayers=v);tog("Moblar",()->c.hitboxMobs,v->c.hitboxMobs=v);sld("Masofa",5,64,()->(float)c.hitboxRange,v->c.hitboxRange=(int)v);sld("Shaffoflik",0,1,()->c.hitboxOpacity,v->c.hitboxOpacity=v);tog("Ism ko'rsatish",()->c.showPlayerTag,v->c.showPlayerTag=v);}
        case 2->{sec("ZARRALAR");tog("Faol",()->c.particlesEnabled,v->c.particlesEnabled=v);sld("Miqdor",0,100,()->(float)c.particleCount,v->c.particleCount=(int)v);sld("Tezlik",0.5f,10f,()->c.particleSpeed,v->c.particleSpeed=v);sld("O'lcham",0.5f,5f,()->c.particleSize,v->c.particleSize=v);sec("HIT EFFEKTI");tog("Hit effekti",()->c.hitEffectEnabled,v->c.hitEffectEnabled=v);tog("Blok buzish",()->c.blockBreakEffect,v->c.blockBreakEffect=v);sld("Intensivlik",0,10,()->(float)c.blockBreakIntensity,v->c.blockBreakIntensity=(int)v);}
        case 3->{sec("BASHORAT");tog("Faol",()->c.trajectoryEnabled,v->c.trajectoryEnabled=v);tog("Boshqa o'yinchilar",()->c.trajectoryOtherPlayers,v->c.trajectoryOtherPlayers=v);sec("QUROLLAR");tog("Trident",()->c.trajectoryTrident,v->c.trajectoryTrident=v);tog("Kamon",()->c.trajectoryBow,v->c.trajectoryBow=v);tog("Ender Pearl",()->c.trajectoryEnderPearl,v->c.trajectoryEnderPearl=v);tog("Snowball",()->c.trajectorySnowball,v->c.trajectorySnowball=v);tog("Potion",()->c.trajectoryPotion,v->c.trajectoryPotion=v);sec("KO'RINISH");sld("Uzunlik",5,60,()->(float)c.trajectoryLength,v->c.trajectoryLength=(int)v);tog("Oxirgi marker",()->c.trajectoryEndMarker,v->c.trajectoryEndMarker=v);}
        case 4->{sec("DUNYO");tog("Tuman",()->c.fogEnabled,v->c.fogEnabled=v);sld("Tuman zichligi",0,1,()->c.fogDensity,v->c.fogDensity=v);tog("Yomg'ir",()->c.rainEnabled,v->c.rainEnabled=v);tog("Qor",()->c.snowEnabled,v->c.snowEnabled=v);}
        case 5->{sec("QO'L");tog("Ko'rsatish",()->c.showHand,v->c.showHand=v);tog("Chap qo'l",()->c.leftHand,v->c.leftHand=v);sld("X",- 50,50,()->c.handX,v->c.handX=v);sld("Y",-50,50,()->c.handY,v->c.handY=v);sld("Z",-50,50,()->c.handZ,v->c.handZ=v);sld("Tilt",-45,45,()->c.handTilt,v->c.handTilt=v);sec("KAMERA");tog("Erkin kamera",()->c.freecamEnabled,v->c.freecamEnabled=v);tog("Custom FOV",()->c.customFov,v->c.customFov=v);sld("FOV",60,120,()->c.fov,v->c.fov=v);tog("View bob o'chirish",()->c.noViewBob,v->c.noViewBob=v);}
        case 6->{sec("BLOQLAR");tog("Faol",()->c.blockOverlayEnabled,v->c.blockOverlayEnabled=v);tog("Koordinatalar",()->c.showBlockCoords,v->c.showBlockCoords=v);tog("Blok ID",()->c.showBlockId,v->c.showBlockId=v);sld("Chiziq qalinligi",0.5f,5f,()->c.blockOutlineWidth,v->c.blockOutlineWidth=v);sec("BUZISH EFFEKTI");tog("Effekt",()->c.blockBreakOverlay,v->c.blockBreakOverlay=v);sld("Intensivlik",0,10,()->(float)c.blockBreakIntensity,v->c.blockBreakIntensity=(int)v);}
        }}
    private void sec(String l){els.add(new String[]{l});}
    private void tog(String l,Supplier<Boolean> g,Consumer<Boolean> s){els.add(new Object[]{l,g,s,Boolean.class});}
    private void sld(String l,float mn,float mx,Supplier<Float> g,Consumer<Float> s){els.add(new Object[]{l,g,s,mn,mx});}
    @Override public void render(DrawContext ctx,int mx,int my,float d){
        ctx.fillGradient(0,0,width,height,0x80000000,0xA0000000);
        ctx.fill(gX,gY,gX+GW,gY+GH,BG);
        ctx.fill(gX,gY,gX+GW,gY+2,RED);
        renderHeader(ctx); renderTabs(ctx,mx,my); renderContent(ctx,mx,my);
        ctx.fill(gX,gY,gX+1,gY+GH,0xFF1A1A28); ctx.fill(gX+GW-1,gY,gX+GW,gY+GH,0xFF1A1A28); ctx.fill(gX,gY+GH-1,gX+GW,gY+GH,0xFF1A1A28);
    }
    private void renderHeader(DrawContext ctx){
        ctx.fill(gX,gY+2,gX+GW,gY+HH,0xFF0A0A14);
        ctx.fill(gX+5,gY+5,gX+9,gY+17,RED);
        ctx.drawText(textRenderer,"SINSATA",gX+13,gY+6,RED,false);
        ctx.drawText(textRenderer,"VISUALS",gX+13+textRenderer.getWidth("SINSATA")+3,gY+6,MUTED,false);
        String v="v1.0 | Fabric 1.21.5";
        ctx.drawText(textRenderer,v,gX+GW-textRenderer.getWidth(v)-5,gY+6,MUTED,false);
    }
    private void renderTabs(DrawContext ctx,int mx,int my){
        int tw=(GW-4)/TABS.length,ty=gY+HH;
        for(int i=0;i<TABS.length;i++){
            int tx=gX+2+i*tw; boolean act=i==tab,hov=mx>=tx&&mx<tx+tw&&my>=ty&&my<ty+TH;
            ctx.fill(tx,ty,tx+tw,ty+TH,act?PANEL:hov?HOV:0xFF080812);
            if(act) ctx.fill(tx,ty,tx+tw,ty+2,RED);
            int tc=act?RED:hov?TEXT:MUTED;
            ctx.drawText(textRenderer,TABS[i],tx+(tw-textRenderer.getWidth(TABS[i]))/2,ty+5,tc,false);
        }
    }
    private void renderContent(DrawContext ctx,int mx,int my){
        int cx=gX+4,cy=gY+HH+TH,cw=GW-8,ch=GH-HH-TH-4;
        ctx.fill(cx,cy,cx+cw,cy+ch,PANEL);
        ctx.enableScissor(cx,cy,cx+cw,cy+ch);
        int colW=(cw-GAP)/2,ex=cx+2,ey=cy+2-scrollY,col=0;
        for(int i=0;i<els.size();i++){Object e=els.get(i);
            if(e instanceof String[]sec){if(col==1){ey+=EH;col=0;}ctx.fill(ex,ey+9,ex+cw-4,ey+10,0xFF1A1A28);ctx.drawText(textRenderer,sec[0],ex+2,ey+1,RED,false);ey+=14;}
            else{int elX=ex+(col==0?0:colW+GAP),elY=ey;boolean hov=mx>=elX&&mx<elX+colW&&my>=elY&&my<elY+EH;
                if(e instanceof Object[]arr){if(arr.length==4&&arr[3]==Boolean.class){renderTog(ctx,arr,elX,elY,colW,hov);}else if(arr.length==5){renderSld(ctx,arr,i,elX,elY,colW,hov);}}
                col++;if(col>=2){col=0;ey+=EH;}}}
        ctx.disableScissor();
        ctx.fill(cx,cy+ch-14,cx+cw,cy+ch,0xFF080812);
        ctx.drawText(textRenderer,"RShift=GUI  H=Hitbox  P=Zarralar  F5=Yorug'lik  F6=Bashorat",cx+4,cy+ch-10,MUTED,false);
    }
    @SuppressWarnings("unchecked")
    private void renderTog(DrawContext ctx,Object[]arr,int x,int y,int w,boolean hov){
        String lbl=(String)arr[0]; boolean val=((Supplier<Boolean>)arr[1]).get();
        ctx.fill(x,y,x+w,y+EH-1,hov?HOV:0xFF0C0C18); if(hov)ctx.fill(x,y,x+1,y+EH-1,RED);
        ctx.drawText(textRenderer,lbl,x+6,y+6,TEXT,false);
        int sw=28,sh=12,sx=x+w-sw-4,sy=y+4;
        ctx.fill(sx,sy,sx+sw,sy+sh,val?ON:OFF);
        int kx=val?sx+sw-sh:sx; ctx.fill(kx+1,sy+1,kx+sh-1,sy+sh-1,val?0xFFFFFFFF:0xFF444455);
    }
    @SuppressWarnings("unchecked")
    private void renderSld(DrawContext ctx,Object[]arr,int idx,int x,int y,int w,boolean hov){
        String lbl=(String)arr[0]; float val=((Supplier<Float>)arr[1]).get(),mn=(float)arr[3],mx2=(float)arr[4];
        float pct=Math.max(0,Math.min(1,(val-mn)/(mx2-mn)));
        ctx.fill(x,y,x+w,y+EH-1,hov||drag==idx?HOV:0xFF0C0C18); if(hov||drag==idx)ctx.fill(x,y,x+1,y+EH-1,RED);
        ctx.drawText(textRenderer,lbl,x+6,y+2,TEXT,false);
        int bx=x+6,by=y+12,bw=w-60,bh=4;
        ctx.fill(bx,by,bx+bw,by+bh,SBG); int fw=(int)(bw*pct); if(fw>0)ctx.fill(bx,by,bx+fw,by+bh,SFG);
        int kx=bx+fw-2; ctx.fill(kx,by-1,kx+4,by+bh+1,0xFFFFFFFF);
        String vs=mx2<=1.01f?String.format("%.2f",val):mx2<=10.01f?String.format("%.1f",val):String.format("%d",(int)val);
        ctx.drawText(textRenderer,vs,x+w-textRenderer.getWidth(vs)-4,y+2,RED,false);
    }
    @Override public boolean mouseClicked(double mx,double my,int btn){
        int imx=(int)mx,imy=(int)my;
        int tw=(GW-4)/TABS.length,ty=gY+HH;
        for(int i=0;i<TABS.length;i++){int tx=gX+2+i*tw;if(imx>=tx&&imx<tx+tw&&imy>=ty&&imy<ty+TH){tab=i;rebuild();return true;}}
        int cx=gX+4,cy=gY+HH+TH,cw=GW-8,colW=(cw-GAP)/2,ex=cx+2,ey=cy+2-scrollY,col=0;
        for(int i=0;i<els.size();i++){Object e=els.get(i);
            if(e instanceof String[]){if(col==1){ey+=EH;col=0;}ey+=14;continue;}
            int elX=ex+(col==0?0:colW+GAP),elY=ey;
            if(imx>=elX&&imx<elX+colW&&imy>=elY&&imy<elY+EH){
                if(e instanceof Object[]arr){
                    if(arr.length==4&&arr[3]==Boolean.class){@SuppressWarnings("unchecked")Supplier<Boolean>g=(Supplier<Boolean>)arr[1];@SuppressWarnings("unchecked")Consumer<Boolean>s=(Consumer<Boolean>)arr[2];s.accept(!g.get());SinsataVisuals.config.save();}
                    else if(arr.length==5){drag=i;updSld(arr,elX,colW,imx);SinsataVisuals.config.save();}}
                return true;}
            col++;if(col>=2){col=0;ey+=EH;}}
        return super.mouseClicked(mx,my,btn);}
    @SuppressWarnings("unchecked")
    private void updSld(Object[]arr,int elX,int colW,int mx){
        float mn=(float)arr[3],mx2=(float)arr[4];
        float pct=Math.max(0,Math.min(1,(mx-(elX+6))/(float)(colW-60)));
        ((Consumer<Float>)arr[2]).accept(mn+pct*(mx2-mn));
    }
    @Override public boolean mouseDragged(double mx,double my,int btn,double dx,double dy){
        if(drag>=0&&drag<els.size()&&els.get(drag)instanceof Object[]arr&&arr.length==5){
            int cx=gX+4,cw=GW-8,colW=(cw-GAP)/2,ex=cx+2,ey=gY+HH+TH+2-scrollY,col=0;
            for(int i=0;i<drag;i++){Object e=els.get(i);if(e instanceof String[]){if(col==1){ey+=EH;col=0;}ey+=14;continue;}col++;if(col>=2){col=0;ey+=EH;}}
            int elX=ex+(col==0?0:colW+GAP); updSld(arr,elX,colW,(int)mx); SinsataVisuals.config.save();}
        return super.mouseDragged(mx,my,btn,dx,dy);}
    @Override public boolean mouseReleased(double mx,double my,int btn){drag=-1;return super.mouseReleased(mx,my,btn);}
    @Override public boolean mouseScrolled(double mx,double my,double hAmt,double vAmt){scrollY=Math.max(0,scrollY-(int)(vAmt*10));return true;}
    @Override public boolean shouldPause(){return false;}
}
