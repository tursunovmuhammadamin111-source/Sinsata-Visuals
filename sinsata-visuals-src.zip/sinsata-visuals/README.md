# Sinsata Visuals

**Minecraft 1.20.1 Fabric** uchun professional visuals mod — Night DLC uslubida.

## O'rnatish

1. [Fabric Loader 0.14.22+](https://fabricmc.net/use/) o'rnating
2. [Fabric API](https://modrinth.com/mod/fabric-api) yuklab oling
3. `sinsata-visuals-1.0.0.jar` faylini `.minecraft/mods/` papkasiga tashlang

## Qurish (Build)

```bash
./gradlew build
```
JAR fayli: `build/libs/sinsata-visuals-1.0.0.jar`

## Funksiyalar

| Funksiya | Tugma | Tavsif |
|---|---|---|
| GUI ochish | `RShift` | Barcha sozlamalar |
| Hitbox | `H` | O'yinchi/mob hitbox |
| To'liq yorug'lik | `F5` | Night vision effekti |
| Bashorat | `F6` | Trident/Kamon/Pearl yo'nalishi |
| Zarralar | `P` | Custom particle effektlar |

## Meteor Client bilan moslik

✅ To'liq mos. Meteor Client bilan parallel ishlaydi:
- Biz **priority=900**, Meteor **priority=1000** (Meteor ustun)
- Har bir funksiyani alohida yoqish/o'chirish mumkin
- Agar Meteor'da ham Fullbright/NoHurtCam bo'lsa — Sinsata'nikini o'chiring

## Sozlamalar fayli

`.minecraft/config/sinsata-visuals.json`
