package com.sinsata.visuals.render;

import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.thrown.EnderPearlEntity;
import net.minecraft.entity.thrown.ExperienceBottleEntity;
import net.minecraft.entity.thrown.SnowballEntity;
import net.minecraft.entity.thrown.PotionEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;

/**
 * Bashorat chizuvchi - trident, kamon, ender pearl, snowball, potion
 * Boshqa o'yinchilarnikilarni ham ko'rsatadi
 */
public class TrajectoryRenderer {

    private static final double DRAG_ARROW   = 0.99;
    private static final double DRAG_PEARL   = 0.99;
    private static final double DRAG_BALL    = 0.99;
    private static final double GRAV_ARROW   = 0.05;
    private static final double GRAV_TRIDENT = 0.05;
    private static final double GRAV_PEARL   = 0.03;
    private static final double GRAV_BALL    = 0.03;

    public static void render(MatrixStack matrices, Camera camera, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        SinsataConfig cfg = SinsataVisuals.config;
        Vec3d cam = camera.getPos();

        VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();

        for (Entity entity : mc.world.getEntities()) {
            double gravity;
            double drag;
            boolean isMine = entity.getOwner() == mc.player;
            boolean isOther = !isMine && cfg.trajectoryOtherPlayers;
            if (!isMine && !isOther) continue;

            if      (entity instanceof ArrowEntity   && cfg.trajectoryBow)         { gravity=GRAV_ARROW;   drag=DRAG_ARROW; }
            else if (entity instanceof TridentEntity && cfg.trajectoryTrident)     { gravity=GRAV_TRIDENT; drag=DRAG_ARROW; }
            else if (entity instanceof EnderPearlEntity && cfg.trajectoryEnderPearl){ gravity=GRAV_PEARL;  drag=DRAG_PEARL; }
            else if (entity instanceof SnowballEntity && cfg.trajectorySnowball)   { gravity=GRAV_BALL;    drag=DRAG_BALL;  }
            else if (entity instanceof PotionEntity  && cfg.trajectoryPotion)      { gravity=GRAV_BALL;    drag=DRAG_BALL;  }
            else continue;

            Vec3d pos = entity.getLerpedPos(tickDelta);
            Vec3d vel = entity.getVelocity();
            List<Vec3d> path = simulate(pos, vel, gravity, drag, cfg.trajectoryLength);
            float[] col = hexToRgba(cfg.trajectoryColor);

            drawPath(matrices, imm, path, cam, col);

            if (cfg.trajectoryEndMarker && !path.isEmpty()) {
                drawMarker(matrices, imm, path.get(path.size()-1), cam, col);
            }
        }

        imm.draw();
    }

    private static List<Vec3d> simulate(Vec3d p, Vec3d v, double gravity, double drag, int steps) {
        List<Vec3d> pts = new ArrayList<>();
        double x=p.x, y=p.y, z=p.z;
        double vx=v.x, vy=v.y, vz=v.z;
        pts.add(new Vec3d(x,y,z));
        for (int i=0; i<steps; i++) {
            vx*=drag; vy-=gravity; vy*=drag; vz*=drag;
            x+=vx; y+=vy; z+=vz;
            pts.add(new Vec3d(x,y,z));
            if (y < -64) break;
        }
        return pts;
    }

    private static void drawPath(MatrixStack ms, VertexConsumerProvider.Immediate imm,
                                  List<Vec3d> pts, Vec3d cam, float[] col) {
        if (pts.size() < 2) return;
        VertexConsumer vc = imm.getBuffer(RenderLayer.getLines());
        Matrix4f m = ms.peek().getPositionMatrix();
        for (int i=0; i<pts.size()-1; i++) {
            Vec3d a=pts.get(i), b=pts.get(i+1);
            float ax=(float)(a.x-cam.x), ay=(float)(a.y-cam.y), az=(float)(a.z-cam.z);
            float bx=(float)(b.x-cam.x), by=(float)(b.y-cam.y), bz=(float)(b.z-cam.z);
            float nx=bx-ax,ny=by-ay,nz=bz-az;
            float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
            if(len>0){nx/=len;ny/=len;nz/=len;}
            vc.vertex(m,ax,ay,az).color(col[0],col[1],col[2],col[3]).normal(nx,ny,nz).next();
            vc.vertex(m,bx,by,bz).color(col[0],col[1],col[2],col[3]).normal(nx,ny,nz).next();
        }
    }

    private static void drawMarker(MatrixStack ms, VertexConsumerProvider.Immediate imm,
                                    Vec3d pos, Vec3d cam, float[] col) {
        float s=0.2f;
        float px=(float)(pos.x-cam.x), py=(float)(pos.y-cam.y), pz=(float)(pos.z-cam.z);
        VertexConsumer vc = imm.getBuffer(RenderLayer.getLines());
        Matrix4f m = ms.peek().getPositionMatrix();
        // 3 o'qda krest
        vc.vertex(m,px-s,py,pz).color(col[0],col[1],col[2],1f).normal(1,0,0).next();
        vc.vertex(m,px+s,py,pz).color(col[0],col[1],col[2],1f).normal(1,0,0).next();
        vc.vertex(m,px,py-s,pz).color(col[0],col[1],col[2],1f).normal(0,1,0).next();
        vc.vertex(m,px,py+s,pz).color(col[0],col[1],col[2],1f).normal(0,1,0).next();
        vc.vertex(m,px,py,pz-s).color(col[0],col[1],col[2],1f).normal(0,0,1).next();
        vc.vertex(m,px,py,pz+s).color(col[0],col[1],col[2],1f).normal(0,0,1).next();
    }

    private static float[] hexToRgba(int hex) {
        return new float[]{((hex>>16)&0xFF)/255f,((hex>>8)&0xFF)/255f,(hex&0xFF)/255f,0.9f};
    }
}
