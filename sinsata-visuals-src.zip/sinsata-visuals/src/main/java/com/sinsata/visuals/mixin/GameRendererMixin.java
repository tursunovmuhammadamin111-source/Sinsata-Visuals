package com.sinsata.visuals.mixin;

import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyReturnValue;

/**
 * Custom FOV.
 * Meteor ham FOV'ni o'zgartiradi - agar Meteor'ning zoom moduli yoqilgan bo'lsa,
 * Meteor ustun bo'ladi (u ham ModifyReturnValue ishlatadi, keyingisi g'alaba qiladi).
 * Xavfsiz: ikkalasi ham faqat float qiymatini o'zgartiradi.
 */
@Mixin(value = GameRenderer.class, priority = 900) // Meteor 1000, biz 900 - Meteor ustun
public class GameRendererMixin {
    @ModifyReturnValue(method = "getFov", at = @At("RETURN"))
    private double modifyFov(double original) {
        if (SinsataVisuals.config != null && SinsataVisuals.config.customFov) {
            return SinsataVisuals.config.fov;
        }
        return original;
    }
}
