package com.sinsata.visuals.mixin;

import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * To'liq yorug'lik (Fullbright) - gamma qiymatini oshiramiz.
 * Meteor bilan to'qnashmaydi: Meteor o'z fullbright moduliga ega,
 * biz cfg.fullbrightEnabled=false qilsak, bu mixin asl qiymatni qaytaradi.
 */
@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 0)
    private float modifyGamma(float gamma) {
        if (SinsataVisuals.config != null && SinsataVisuals.config.fullbrightEnabled) {
            return SinsataVisuals.config.gamma;
        }
        return gamma;
    }
}
