package com.sinsata.visuals.gui;

import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Sinsata Visuals - Night DLC uslubida to'liq GUI
 * 7 ta tab, toggle + slider elementlar, scroll qo'llab-quvvatlaydi.
 * Meteor's ScreenLayer bilan to'qnashmaydi (biz Screen'ni extend qilamiz).
 */
public class SinsataGuiScreen extends Screen {

    // ── Ranglar (Night DLC palette) ─────────────────────────────────────────
    private static final int C_BG        = 0xF0080810;
    private static final int C_PANEL     = 0xFF111118;
    private static final int C_PANEL2    = 0xFF0E0E14;
    private static final int C_BORDER    = 0xFF1C1C28;
    private static final int C_RED       = 0xFFFF3333;
    private static final int C_RED_DIM   = 0xFF8B1818;
    private static final int C_TEXT      = 0xFFDDDDDD;
    private static final int C_MUTED     = 0xFF777788;
    private static final int C_ON        = 0xFFFF3333;
    private static final int C_OFF       = 0xFF2E2E3E;
    private static final int C_SLIDER_BG = 0xFF1E1E2C;
    private static final int C_SLIDER_FG = 0xFFFF3333;
    private static final int C_HOVER     = 0xFF181824;

    // ── Layout ──────────────────────────────────────────────────────────────
    private static final int GUI_W = 480;
    private static final int GUI_H = 300;
    private static final int HEADER_H = 22;
    private static final int TAB_H = 18;
    private static final int ELEM_H = 20;
    private static final int COL_GAP = 6;

    private int gX, gY; // GUI sol-yuqori burchak

    // ── Tab ─────────────────────────────────────────────────────────────────
    private static final String[] TABS = {"HUD","HITBOX","ZARRALAR","BASHORAT","DUNYO","QO'L","BLOQLAR"};
    private int activeTab = 0;

    // ── Elementlar ──────────────────────────────────────────────────────────
    private final List<Elem> elems = new ArrayList<>();
    private int scrollY = 0;
    private int dragging = -1; // slider indeksi

    public SinsataGuiScreen() {
        super(Text.literal("Sinsata Visuals"));
    }

    @Override
    protected void init() {
        gX = (width  - GUI_W) / 2;
        gY = (height - GUI_H) / 2;
        rebuildElems();
    }

    // ── Element qurilishi ───────────────────────────────────────────────────
    private void rebuildElems() {
        elems.clear();
        scrollY = 0;
        SinsataConfig c = SinsataVisuals.config;

        switch (activeTab) {
        case 0 -> { // HUD
            sec("ASOSIY HUD");
            tog("HUD faol",              ()-> c.hudEnabled,         v-> c.hudEnabled=v);
            tog("Hayot ko'rsatish",      ()-> c.showHealth,         v-> c.showHealth=v);
            tog("Chapda joylash",        ()-> c.healthOnLeft,       v-> c.healthOnLeft=v);
            sld("HUD o'lchami",    0.5f,2f, ()-> c.hudScale,        v-> c.hudScale=v);
            tog("Armor",                 ()-> c.showArmor,          v-> c.showArmor=v);
            tog("Koordinatalar",         ()-> c.showCoords,         v-> c.showCoords=v);
            tog("Ping",                  ()-> c.showPing,           v-> c.showPing=v);
            tog("FPS",                   ()-> c.showFps,            v-> c.showFps=v);
            sec("NISHON (CROSSHAIR)");
            tog("Custom crosshair",      ()-> c.customCrosshair,    v-> c.customCrosshair=v);
            sld("O'lcham",         2,20,  ()-> (float)c.crosshairSize,  v-> c.crosshairSize=(int)v);
            sld("Qalinlik",        1,5,   ()-> (float)c.crosshairThickness, v-> c.crosshairThickness=(int)v);
            tog("Sakrash doirasi",       ()-> c.showJumpCircle,     v-> c.showJumpCircle=v);
            sec("YORUG'LIK");
            tog("To'liq yorug'lik",      ()-> c.fullbrightEnabled,  v-> c.fullbrightEnabled=v);
            sld("Gamma",           1,32, ()-> c.gamma,              v-> c.gamma=v);
            sec("BOSHQA");
            tog("No hurtcam",            ()-> c.noHurtCam,          v-> c.noHurtCam=v);
            tog("Auto sprint",           ()-> c.autoSprint,         v-> c.autoSprint=v);
            tog("Bosh kiyim overlay",    ()-> c.showHelmet,         v-> c.showHelmet=v);
            tog("Effectlar",             ()-> c.showEffects,        v-> c.showEffects=v);
            tog("Izlar (traces)",        ()-> c.tracesEnabled,      v-> c.tracesEnabled=v);
            sld("Izlar uzunligi",  5,60, ()-> (float)c.tracesLength, v-> c.tracesLength=(int)v);
        }
        case 1 -> { // HITBOX
            sec("HITBOX");
            tog("Faol",                  ()-> c.hitboxEnabled,      v-> c.hitboxEnabled=v);
            tog("O'yinchilar",           ()-> c.hitboxPlayers,      v-> c.hitboxPlayers=v);
            tog("Moblar",                ()-> c.hitboxMobs,         v-> c.hitboxMobs=v);
            sld("Ko'rish masofasi", 5,64,()-> (float)c.hitboxRange,  v-> c.hitboxRange=(int)v);
            sld("Shaffoflik",    0,1,    ()-> c.hitboxOpacity,       v-> c.hitboxOpacity=v);
            sld("Chiziq qalinligi",0.5f,3f,()-> c.hitboxLineWidth,  v-> c.hitboxLineWidth=v);
            sec("QO'SHIMCHA");
            tog("O'yinchi tegi",         ()-> c.showPlayerTag,      v-> c.showPlayerTag=v);
            tog("Ism ko'rsatish",        ()-> c.showEntityName,     v-> c.showEntityName=v);
            tog("Xudini yo'q qilish",    ()-> c.noHurtCam,          v-> c.noHurtCam=v);
        }
        case 2 -> { // ZARRALAR
            sec("ZARRALAR");
            tog("Faol",                  ()-> c.particlesEnabled,   v-> c.particlesEnabled=v);
            sld("Miqdor",          0,100,()-> (float)c.particleCount, v-> c.particleCount=(int)v);
            sld("Tezlik",          0.5f,10f,()-> c.particleSpeed,   v-> c.particleSpeed=v);
            sld("O'lcham",         0.5f,5f, ()-> c.particleSize,    v-> c.particleSize=v);
            sec("HIT EFFEKTI");
            tog("Hit effekti faol",      ()-> c.hitEffectEnabled,   v-> c.hitEffectEnabled=v);
            tog("Blok buzish effekti",   ()-> c.blockBreakEffect,   v-> c.blockBreakEffect=v);
            sld("Intensivlik",     0,10, ()-> (float)c.blockBreakIntensity, v-> c.blockBreakIntensity=(int)v);
        }
        case 3 -> { // BASHORAT
            sec("BASHORAT (TRAJECTORY)");
            tog("Faol",                  ()-> c.trajectoryEnabled,        v-> c.trajectoryEnabled=v);
            tog("Boshqa o'yinchilar",    ()-> c.trajectoryOtherPlayers,   v-> c.trajectoryOtherPlayers=v);
            sec("QUROLLAR");
            tog("Trident",               ()-> c.trajectoryTrident,        v-> c.trajectoryTrident=v);
            tog("Kamon (Bow)",           ()-> c.trajectoryBow,            v-> c.trajectoryBow=v);
            tog("Ender Pearl",           ()-> c.trajectoryEnderPearl,     v-> c.trajectoryEnderPearl=v);
            tog("Snowball",              ()-> c.trajectorySnowball,        v-> c.trajectorySnowball=v);
            tog("Potion",                ()-> c.trajectoryPotion,          v-> c.trajectoryPotion=v);
            sec("KO'RINISH");
            sld("Uzunlik",         5,60, ()-> (float)c.trajectoryLength,  v-> c.trajectoryLength=(int)v);
            sld("Qalinlik",       0.5f,5f,()-> c.trajectoryWidth,         v-> c.trajectoryWidth=v);
            tog("Oxirgi marker",         ()-> c.trajectoryEndMarker,       v-> c.trajectoryEndMarker=v);
        }
        case 4 -> { // DUNYO
            sec("DUNYO SOZLAMALARI");
            tog("Tuman (fog)",           ()-> c.fogEnabled,      v-> c.fogEnabled=v);
            sld("Tuman zichligi",  0,1,  ()-> c.fogDensity,      v-> c.fogDensity=v);
            tog("Yomg'ir",               ()-> c.rainEnabled,     v-> c.rainEnabled=v);
            tog("Qor",                   ()-> c.snowEnabled,     v-> c.snowEnabled=v);
        }
        case 5 -> { // QO'L
            sec("QO'L SOZLAMALARI");
            tog("Qo'lni ko'rsatish",    ()-> c.showHand,           v-> c.showHand=v);
            tog("Chap qo'l",            ()-> c.leftHand,            v-> c.leftHand=v);
            sld("X pozitsiya",    -50,50,()-> c.handX,              v-> c.handX=v);
            sld("Y pozitsiya",    -50,50,()-> c.handY,              v-> c.handY=v);
            sld("Z pozitsiya",    -50,50,()-> c.handZ,              v-> c.handZ=v);
            sld("Tilt burchak",   -45,45,()-> c.handTilt,           v-> c.handTilt=v);
            sec("KAMERA (Camera Tweaks)");
            tog("Erkin qarash",          ()-> c.freecamEnabled,     v-> c.freecamEnabled=v);
            sld("Sezgirlik",      0.1f,1f,()-> c.freecamSensitivity,v-> c.freecamSensitivity=v);
            tog("Custom FOV",            ()-> c.customFov,           v-> c.customFov=v);
            sld("FOV",            60,120,()-> c.fov,                v-> c.fov=v);
            tog("View bob o'chirish",    ()-> c.noViewBob,           v-> c.noViewBob=v);
        }
        case 6 -> { // BLOQLAR
            sec("BLOK BELGISI");
            tog("Faol",                  ()-> c.blockOverlayEnabled, v-> c.blockOverlayEnabled=v);
            tog("Koordinatalar",         ()-> c.showBlockCoords,     v-> c.showBlockCoords=v);
            tog("Blok ID",               ()-> c.showBlockId,         v-> c.showBlockId=v);
            sld("Chiziq qalinligi",0.5f,5f,()-> c.blockOutlineWidth,v-> c.blockOutlineWidth=v);
            sec("BUZISH EFFEKTI");
            tog("Buzish effekti",        ()-> c.blockBreakOverlay,   v-> c.blockBreakOverlay=v);
            sld("Intensivlik",     0,10, ()-> (float)c.blockBreakIntensity, v-> c.blockBreakIntensity=(int)v);
        }
        }
    }

    private void sec(String label)  { elems.add(new Sec(label)); }
    private void tog(String label, Supplier<Boolean> g, Consumer<Boolean> s) { elems.add(new Tog(label,g,s)); }
    private void sld(String label, float min, float max, Supplier<Float> g, Consumer<Float> s) { elems.add(new Sld(label,min,max,g,s)); }

    // ── Render ──────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Backdrop
        ctx.fillGradient(0,0,width,height, 0x88000000, 0xAA000000);

        // Asosiy panel
        ctx.fill(gX, gY, gX+GUI_W, gY+GUI_H, C_BG);
        // Yuqori qizil chiziq
        ctx.fill(gX, gY, gX+GUI_W, gY+2, C_RED);

        renderHeader(ctx);
        renderTabs(ctx, mx, my);
        renderContent(ctx, mx, my);

        // Cheka ramka
        ctx.fill(gX,    gY,    gX+1,     gY+GUI_H, C_BORDER);
        ctx.fill(gX+GUI_W-1,gY,gX+GUI_W, gY+GUI_H, C_BORDER);
        ctx.fill(gX,gY+GUI_H-1,gX+GUI_W, gY+GUI_H, C_BORDER);
    }

    private void renderHeader(DrawContext ctx) {
        ctx.fill(gX, gY+2, gX+GUI_W, gY+HEADER_H, 0xFF0C0C12);
        // Qizil aksent blok
        ctx.fill(gX+5, gY+5, gX+9, gY+17, C_RED);
        // Logo matn
        ctx.drawText(textRenderer,"SINSATA", gX+13, gY+6, C_RED, false);
        String vis = "VISUALS";
        ctx.drawText(textRenderer, vis, gX+13+textRenderer.getWidth("SINSATA")+3, gY+6, C_MUTED, false);
        // Versiya
        String ver = "v1.0 | Fabric 1.20.1";
        ctx.drawText(textRenderer, ver, gX+GUI_W-textRenderer.getWidth(ver)-5, gY+6, C_MUTED, false);
    }

    private void renderTabs(DrawContext ctx, int mx, int my) {
        int tabW = (GUI_W - 4) / TABS.length;
        int ty = gY + HEADER_H;
        for (int i = 0; i < TABS.length; i++) {
            int tx = gX + 2 + i * tabW;
            boolean active = i == activeTab;
            boolean hover  = mx>=tx && mx<tx+tabW && my>=ty && my<ty+TAB_H;
            int bg = active ? C_PANEL : (hover ? C_HOVER : 0xFF0A0A10);
            ctx.fill(tx, ty, tx+tabW, ty+TAB_H, bg);
            // Alt chiziq
            if (active) ctx.fill(tx, ty, tx+tabW, ty+2, C_RED);
            int tc = active ? C_RED : (hover ? C_TEXT : C_MUTED);
            int tw = textRenderer.getWidth(TABS[i]);
            ctx.drawText(textRenderer, TABS[i], tx+(tabW-tw)/2, ty+5, tc, false);
        }
    }

    private void renderContent(DrawContext ctx, int mx, int my) {
        int cx = gX + 4;
        int cy = gY + HEADER_H + TAB_H;
        int cw = GUI_W - 8;
        int ch = GUI_H - HEADER_H - TAB_H - 4;

        // Kontent foni
        ctx.fill(cx, cy, cx+cw, cy+ch, C_PANEL);

        ctx.enableScissor(cx, cy, cx+cw, cy+ch);

        int colW = (cw - COL_GAP) / 2;
        int ex = cx + 2;
        int ey = cy + 2 - scrollY;
        int col = 0;

        for (int i = 0; i < elems.size(); i++) {
            Elem e = elems.get(i);
            if (e instanceof Sec sec) {
                // Section sarlavhasi - to'liq kenglik
                if (col == 1) { ey += ELEM_H; col = 0; }
                ctx.fill(ex, ey+8, ex+cw-4, ey+9, C_BORDER);
                ctx.drawText(textRenderer, sec.label, ex+2, ey+1, C_RED, false);
                ey += 14;
            } else {
                int elX = ex + (col==0 ? 0 : colW+COL_GAP);
                int elY = ey;
                boolean hover = mx>=elX && mx<elX+colW && my>=elY && my<elY+ELEM_H;

                if (e instanceof Tog tog) renderTog(ctx, tog, elX, elY, colW, hover);
                if (e instanceof Sld sld) renderSld(ctx, sld, i, elX, elY, colW, hover);

                col++;
                if (col >= 2) { col=0; ey+=ELEM_H; }
            }
        }

        ctx.disableScissor();

        // Pastki chiziq / o'chirish tugmasi
        ctx.fill(cx, cy+ch-16, cx+cw, cy+ch, 0xFF0C0C12);
        ctx.drawText(textRenderer,"[ESC] yopish  |  RShift - ochish  |  F5 fullbright  |  H hitbox",
                cx+4, cy+ch-11, C_MUTED, false);
    }

    private void renderTog(DrawContext ctx, Tog tog, int x, int y, int w, boolean hover) {
        boolean val = tog.g.get();
        int bg = hover ? C_HOVER : C_PANEL2;
        ctx.fill(x,y,x+w,y+ELEM_H-1,bg);
        if (hover) ctx.fill(x,y,x+1,y+ELEM_H-1,C_RED);

        ctx.drawText(textRenderer, tog.label, x+6, y+6, C_TEXT, false);

        // Yirtiq switch (28x12)
        int sw=28,sh=12,sx=x+w-sw-4,sy=y+4;
        ctx.fill(sx,sy,sx+sw,sy+sh, val ? C_ON : C_OFF);
        // Doira knob
        int kx = val ? sx+sw-sh : sx;
        ctx.fill(kx+1,sy+1,kx+sh-1,sy+sh-1, val ? 0xFFFFFFFF : 0xFF555566);
    }

    private void renderSld(DrawContext ctx, Sld sld, int idx, int x, int y, int w, boolean hover) {
        float val = sld.g.get();
        float pct = (val - sld.min) / (sld.max - sld.min);
        pct = Math.max(0, Math.min(1, pct));

        int bg = hover ? C_HOVER : C_PANEL2;
        ctx.fill(x,y,x+w,y+ELEM_H-1,bg);
        if (hover || dragging == idx) ctx.fill(x,y,x+1,y+ELEM_H-1,C_RED);

        ctx.drawText(textRenderer, sld.label, x+6, y+3, C_TEXT, false);

        // Bar
        int bx=x+6, by=y+12, bw=w-60, bh=4;
        ctx.fill(bx,by,bx+bw,by+bh,C_SLIDER_BG);
        int fw = (int)(bw*pct);
        if(fw>0) ctx.fill(bx,by,bx+fw,by+bh,C_SLIDER_FG);
        // Knob
        int kx=bx+fw-2;
        ctx.fill(kx,by-1,kx+4,by+bh+1,0xFFFFFFFF);

        // Qiymat matn
        String vs = sld.max <= 1.01f
            ? String.format("%.2f",val)
            : sld.max <= 10.01f
              ? String.format("%.1f",val)
              : String.format("%d",(int)val);
        ctx.drawText(textRenderer, vs, x+w-textRenderer.getWidth(vs)-4, y+3, C_RED, false);
    }

    // ── Mouse hodisalari ────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int imx=(int)mx, imy=(int)my;

        // Tab bosish
        int tabW2 = (GUI_W-4)/TABS.length;
        int ty = gY + HEADER_H;
        for (int i=0; i<TABS.length; i++) {
            int tx = gX+2+i*tabW2;
            if (imx>=tx && imx<tx+tabW2 && imy>=ty && imy<ty+TAB_H) {
                activeTab = i; rebuildElems(); return true;
            }
        }

        // Element bosish
        int[] pos = getElemPos(0);
        int cx=gX+4, cy2=gY+HEADER_H+TAB_H;
        int cw=GUI_W-8, colW=(cw-COL_GAP)/2;
        int ex2=cx+2, ey2=cy2+2-scrollY, col2=0;

        for (int i=0; i<elems.size(); i++) {
            Elem e = elems.get(i);
            if (e instanceof Sec) { if(col2==1){ey2+=ELEM_H;col2=0;} ey2+=14; continue; }
            int elX=ex2+(col2==0?0:colW+COL_GAP), elY=ey2;
            if (imx>=elX && imx<elX+colW && imy>=elY && imy<elY+ELEM_H) {
                if (e instanceof Tog tog) {
                    tog.s.accept(!tog.g.get());
                    SinsataVisuals.config.save();
                } else if (e instanceof Sld sld) {
                    dragging = i;
                    updateSlider(sld, elX, colW, imx);
                    SinsataVisuals.config.save();
                }
                return true;
            }
            col2++; if(col2>=2){col2=0;ey2+=ELEM_H;}
        }
        return super.mouseClicked(mx,my,btn);
    }

    private int[] getElemPos(int dummy) { return new int[]{0,0}; }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging >= 0 && dragging < elems.size() && elems.get(dragging) instanceof Sld sld) {
            int cx=gX+4, cy2=gY+HEADER_H+TAB_H;
            int cw=GUI_W-8, colW=(cw-COL_GAP)/2;
            int ex2=cx+2, ey2=cy2+2-scrollY, col2=0;
            int targetX=ex2;
            for (int i=0; i<dragging; i++) {
                Elem e=elems.get(i);
                if(e instanceof Sec){if(col2==1){ey2+=ELEM_H;col2=0;}ey2+=14;continue;}
                col2++; if(col2>=2){col2=0;ey2+=ELEM_H;}
            }
            if(col2==1) targetX=ex2+colW+COL_GAP;
            updateSlider(sld, targetX, colW, (int)mx);
            SinsataVisuals.config.save();
        }
        return super.mouseDragged(mx,my,btn,dx,dy);
    }

    private void updateSlider(Sld sld, int elX, int colW, int mx) {
        int bx=elX+6, bw=colW-60;
        float pct=Math.max(0,Math.min(1,(mx-bx)/(float)bw));
        sld.s.accept(sld.min + pct*(sld.max-sld.min));
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = -1; return super.mouseReleased(mx,my,btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scrollY = Math.max(0, scrollY-(int)(amount*10)); return true;
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }

    // ── Element sinflar ─────────────────────────────────────────────────────
    interface Elem {}
    record Sec(String label) implements Elem {}
    record Tog(String label, Supplier<Boolean> g, Consumer<Boolean> s) implements Elem {}
    record Sld(String label, float min, float max, Supplier<Float> g, Consumer<Float> s) implements Elem {}
}
