package com.sinsata.visuals.mixin;

import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.render.HitboxRenderer;
import com.sinsata.visuals.render.TrajectoryRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hitbox va Trajectory render.
 * Meteor ham WorldRenderer'ga inject qiladi, lekin boshqa method/at joylarida.
 * Ikkala @Inject ham ishlaydi - Mixin framework buni hal qiladi.
 */
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(MatrixStack matrices, float tickDelta, long limitTime,
                               boolean renderBlockOutline, Camera camera,
                               GameRenderer gameRenderer,
                               LightmapTextureManager lightmapTextureManager,
                               Matrix4f projectionMatrix, CallbackInfo ci) {
        if (SinsataVisuals.config == null) return;
        if (SinsataVisuals.config.hitboxEnabled)     HitboxRenderer.render(matrices, camera, tickDelta);
        if (SinsataVisuals.config.trajectoryEnabled) TrajectoryRenderer.render(matrices, camera, tickDelta);
    }
}
