package com.sinsata.visuals.render;

import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class HitboxRenderer {

    public static void render(MatrixStack matrices, Camera camera, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        SinsataConfig cfg = SinsataVisuals.config;
        Vec3d cam = camera.getPos();

        VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;

            boolean isPlayer = entity instanceof PlayerEntity && cfg.hitboxPlayers;
            boolean isMob    = entity instanceof HostileEntity && cfg.hitboxMobs;
            if (!isPlayer && !isMob) continue;

            if (mc.player.distanceTo(entity) > cfg.hitboxRange) continue;

            Vec3d lerpedPos = entity.getLerpedPos(tickDelta);
            Box box = entity.getBoundingBox().offset(lerpedPos.negate());

            float[] col = isPlayer
                ? hexToRgba(cfg.hitboxEnemyColor, cfg.hitboxOpacity)
                : hexToRgba(cfg.hitboxFriendColor, cfg.hitboxOpacity);

            matrices.push();
            matrices.translate(lerpedPos.x - cam.x, lerpedPos.y - cam.y, lerpedPos.z - cam.z);

            VertexConsumer vc = imm.getBuffer(RenderLayer.getLines());
            drawBox(matrices.peek().getPositionMatrix(), vc,
                    (float)box.minX, (float)box.minY, (float)box.minZ,
                    (float)box.maxX, (float)box.maxY, (float)box.maxZ,
                    col[0], col[1], col[2], col[3]);
            matrices.pop();
        }
        imm.draw();
    }

    private static void drawBox(Matrix4f m, VertexConsumer vc,
                                 float x1,float y1,float z1,
                                 float x2,float y2,float z2,
                                 float r,float g,float b,float a) {
        // Pastki 4 qirra
        line(m,vc, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(m,vc, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(m,vc, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(m,vc, x1,y1,z2, x1,y1,z1, r,g,b,a);
        // Yuqori 4 qirra
        line(m,vc, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(m,vc, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(m,vc, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(m,vc, x1,y2,z2, x1,y2,z1, r,g,b,a);
        // 4 vertikal qirra
        line(m,vc, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(m,vc, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(m,vc, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(m,vc, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private static void line(Matrix4f m, VertexConsumer vc,
                              float ax,float ay,float az,
                              float bx,float by,float bz,
                              float r,float g,float b,float a) {
        float nx=bx-ax, ny=by-ay, nz=bz-az;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len>0){nx/=len;ny/=len;nz/=len;}
        vc.vertex(m,ax,ay,az).color(r,g,b,a).normal(nx,ny,nz).next();
        vc.vertex(m,bx,by,bz).color(r,g,b,a).normal(nx,ny,nz).next();
    }

    private static float[] hexToRgba(int hex, float alpha) {
        return new float[]{
            ((hex>>16)&0xFF)/255f,
            ((hex>>8)&0xFF)/255f,
            (hex&0xFF)/255f,
            alpha
        };
    }
}
