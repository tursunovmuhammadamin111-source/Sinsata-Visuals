package com.sinsata.visuals.mixin;

import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla HUD elementlarini o'chiramiz (faqat bizniki yoqilganda).
 * Meteor o'z HUD'ini ishlatadi, bizniki esa HudRenderCallback orqali chiziladi.
 * Shuning uchun ikkalasi parallel ishlaydi.
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void cancelVanillaCrosshair(DrawContext ctx, CallbackInfo ci) {
        if (SinsataVisuals.config != null && SinsataVisuals.config.customCrosshair) {
            ci.cancel();
        }
    }

    @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
    private void cancelVanillaHealth(DrawContext ctx, CallbackInfo ci) {
        if (SinsataVisuals.config != null && SinsataVisuals.config.showHealth) {
            ci.cancel();
        }
    }

    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void cancelHelmetOverlay(DrawContext ctx, float f, CallbackInfo ci) {
        if (SinsataVisuals.config != null && !SinsataVisuals.config.showHelmet) {
            ci.cancel();
        }
    }
}
