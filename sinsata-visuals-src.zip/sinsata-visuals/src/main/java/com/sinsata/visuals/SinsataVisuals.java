package com.sinsata.visuals;

import com.sinsata.visuals.config.SinsataConfig;
import com.sinsata.visuals.gui.SinsataGuiScreen;
import com.sinsata.visuals.module.ModuleManager;
import com.sinsata.visuals.render.SinsataHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Sinsata Visuals - Asosiy kirish nuqtasi
 * Meteor Client bilan mos: biz Meteor'ning hech bir sinfiga tegmaymiz,
 * o'z keybind/mixin/render sistemamizni ishlatamiz.
 */
public class SinsataVisuals implements ClientModInitializer {

    public static final String MOD_ID = "sinsata-visuals";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static SinsataConfig config;
    public static ModuleManager moduleManager;
    public static SinsataHudRenderer hudRenderer;

    // Keybindlar (Meteor bilan to'qnashmaydi - boshqa tugmalar)
    public static KeyBinding openGuiKey;
    public static KeyBinding toggleHitboxKey;
    public static KeyBinding toggleParticlesKey;
    public static KeyBinding toggleFullbrightKey;
    public static KeyBinding toggleTrajectoryKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[SinsataVisuals] Yuklanmoqda...");

        config = SinsataConfig.load();
        moduleManager = new ModuleManager();
        hudRenderer = new SinsataHudRenderer();

        // Keybindlar - Meteor ishlatadigan tugmalardan farqli
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sinsata-visuals.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.sinsata-visuals"
        ));
        toggleHitboxKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sinsata-visuals.hitbox",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.sinsata-visuals"
        ));
        toggleParticlesKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sinsata-visuals.particles",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                "category.sinsata-visuals"
        ));
        toggleFullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sinsata-visuals.fullbright",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F5,
                "category.sinsata-visuals"
        ));
        toggleTrajectoryKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sinsata-visuals.trajectory",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F6,
                "category.sinsata-visuals"
        ));

        // Tick eventi
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            moduleManager.onTick(client);

            if (openGuiKey.wasPressed()) {
                client.setScreen(new SinsataGuiScreen());
            }
            if (toggleHitboxKey.wasPressed()) {
                config.hitboxEnabled = !config.hitboxEnabled;
                config.save();
            }
            if (toggleParticlesKey.wasPressed()) {
                config.particlesEnabled = !config.particlesEnabled;
                config.save();
            }
            if (toggleFullbrightKey.wasPressed()) {
                config.fullbrightEnabled = !config.fullbrightEnabled;
                config.save();
            }
            if (toggleTrajectoryKey.wasPressed()) {
                config.trajectoryEnabled = !config.trajectoryEnabled;
                config.save();
            }
        });

        // HUD render
        HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
                hudRenderer.render(drawContext, tickDelta));

        LOGGER.info("[SinsataVisuals] Tayyor! Meteor Client bilan mos.");
    }
}
