package com.sinsata.visuals.module;

import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.MinecraftClient;

/**
 * Modul boshqaruvchi - tick-based logika
 * Meteor bilan mos: Meteor o'z ModuleManager'ini ishlatadi, biz o'zimiznikini.
 */
public class ModuleManager {

    private boolean wasMovingForward = false;

    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        // Auto Sprint - Meteor'ning sprint moduli o'chirilgan bo'lsa ishlaydi
        if (SinsataVisuals.config.autoSprint) {
            boolean movingForward = client.player.input != null &&
                                    client.player.input.movementForward > 0;
            if (movingForward && !client.player.isSneaking()) {
                client.player.setSprinting(true);
            }
        }
    }
}
