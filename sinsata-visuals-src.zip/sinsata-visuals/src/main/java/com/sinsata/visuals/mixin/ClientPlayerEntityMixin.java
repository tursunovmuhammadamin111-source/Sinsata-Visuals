package com.sinsata.visuals.mixin;

import com.sinsata.visuals.SinsataVisuals;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * O'yinchi logikasi - faqat kuzatuvchi, hech narsani bekor qilmaydi.
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        // ModuleManager onTick da hal qilinadi
    }
}
