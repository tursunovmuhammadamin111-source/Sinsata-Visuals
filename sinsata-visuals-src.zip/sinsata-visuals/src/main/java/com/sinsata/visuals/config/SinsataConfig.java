package com.sinsata.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.Path;

/**
 * Sinsata Visuals - Barcha sozlamalar
 * Meteor Client bilan mos (o'z package, o'z config fayli)
 */
public class SinsataConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("sinsata-visuals.json");

    // HUD
    public boolean hudEnabled = true;
    public boolean showHealth = true;
    public boolean healthOnLeft = true;
    public int healthColor = 0xFF4444;
    public boolean showPing = true;
    public boolean showFps = true;
    public float hudScale = 1.0f;
    public boolean showArmor = true;
    public boolean showCoords = true;

    // CROSSHAIR / NISHON
    public boolean customCrosshair = true;
    public int crosshairType = 0; // 0=krest 1=nuqta 2=doira 3=T
    public int crosshairSize = 8;
    public int crosshairThickness = 2;
    public int crosshairColor = 0xFFFFFF;
    public boolean showJumpCircle = true;
    public boolean showAttackIndicator = true;

    // FULLBRIGHT / YORUGLIK
    public boolean fullbrightEnabled = true;
    public float gamma = 16.0f;
    public boolean nightVisionMode = false;

    // HITBOX
    public boolean hitboxEnabled = true;
    public boolean hitboxPlayers = true;
    public boolean hitboxMobs = false;
    public int hitboxEnemyColor = 0xFF4444;
    public int hitboxFriendColor = 0x44FF88;
    public float hitboxOpacity = 0.8f;
    public float hitboxLineWidth = 1.0f;
    public int hitboxRange = 32;
    public boolean showPlayerTag = true;
    public boolean showEntityName = true;

    // PARTICLES / ZARRALAR
    public boolean particlesEnabled = true;
    public int particleType = 0;
    public int particleCount = 60;
    public float particleSpeed = 4.0f;
    public float particleSize = 1.0f;
    public int particleColor = 0xFF4444;

    // HIT EFFECT
    public boolean hitEffectEnabled = true;
    public int hitEffectColor = 0xFF4444;
    public boolean blockBreakEffect = true;
    public int blockBreakIntensity = 7;

    // TRAJECTORY / BASHORAT
    public boolean trajectoryEnabled = true;
    public boolean trajectoryOtherPlayers = true;
    public boolean trajectoryTrident = true;
    public boolean trajectoryBow = true;
    public boolean trajectoryEnderPearl = true;
    public boolean trajectorySnowball = false;
    public boolean trajectoryPotion = true;
    public boolean trajectoryFishingRod = false;
    public int trajectoryLineType = 0;
    public int trajectoryColor = 0xFF4444;
    public int trajectoryLength = 30;
    public float trajectoryWidth = 2.0f;
    public boolean trajectoryEndMarker = true;

    // HAND / QO'L
    public boolean showHand = true;
    public boolean leftHand = false;
    public float handX = 0.0f;
    public float handY = 0.0f;
    public float handZ = 0.0f;
    public float handTilt = 0.0f;

    // FREECAM / ERKIN QARASH (Camera Tweaks)
    public boolean freecamEnabled = false;
    public float freecamSensitivity = 0.6f;
    public boolean customFov = false;
    public float fov = 90.0f;
    public boolean noViewBob = false;

    // WORLD / DUNYO
    public boolean fogEnabled = false;
    public float fogDensity = 0.0f;
    public boolean rainEnabled = true;
    public boolean snowEnabled = true;

    // BLOCKS / BLOKLAR
    public boolean blockOverlayEnabled = true;
    public boolean showBlockCoords = true;
    public boolean showBlockId = false;
    public int blockOutlineColor = 0xFFFFFF;
    public float blockOutlineWidth = 1.0f;
    public boolean blockBreakOverlay = true;
    public int blockBreakColor = 0xFF8800;

    // SPRINT
    public boolean autoSprint = true;
    public boolean sprintToggle = true;

    // TRACES / IZLAR
    public boolean tracesEnabled = false;
    public int tracesLength = 20;
    public int tracesColor = 0xFF4444;

    // HELMET OVERLAY
    public boolean showHelmet = false;

    // NO HURT CAM
    public boolean noHurtCam = true;

    // EFFECTS / EFFECTLAR
    public boolean showEffects = true;
    public boolean effectIcons = true;
    public int effectsPosition = 0; // 0=top-right

    public static SinsataConfig load() {
        if (CONFIG_PATH.toFile().exists()) {
            try (Reader r = new FileReader(CONFIG_PATH.toFile())) {
                SinsataConfig cfg = GSON.fromJson(r, SinsataConfig.class);
                return cfg != null ? cfg : new SinsataConfig();
            } catch (Exception e) { return new SinsataConfig(); }
        }
        SinsataConfig cfg = new SinsataConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try (Writer w = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(this, w);
        } catch (Exception ignored) {}
    }
}
