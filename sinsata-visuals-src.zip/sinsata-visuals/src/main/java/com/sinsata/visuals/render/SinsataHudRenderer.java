package com.sinsata.visuals.render;

import com.sinsata.visuals.SinsataVisuals;
import com.sinsata.visuals.config.SinsataConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;

/**
 * HUD Renderer - Night DLC uslubida
 * Meteor bilan mos: HudRenderCallback.EVENT ishlatiladi, Meteor ham shunday qiladi.
 * Ikkalasi ham ishlaydi, hech qisi biri-birini bekor qilmaydi.
 */
public class SinsataHudRenderer {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public void render(DrawContext ctx, float tickDelta) {
        SinsataConfig cfg = SinsataVisuals.config;
        if (!cfg.hudEnabled) return;
        if (mc.player == null || mc.world == null) return;
        if (mc.options.hudHidden) return;
        // Spektator modida HUD ko'rsatmaymiz
        if (mc.player.isSpectator()) return;

        ClientPlayerEntity player = mc.player;
        TextRenderer font = mc.textRenderer;
        int W = mc.getWindow().getScaledWidth();
        int H = mc.getWindow().getScaledHeight();

        // === HEALTH PANEL (Night DLC uslub) ===
        if (cfg.showHealth) renderHealth(ctx, font, player, cfg, W, H);

        // === PING + FPS (yuqori o'ng) ===
        if (cfg.showPing || cfg.showFps) renderInfoTopRight(ctx, font, player, cfg, W);

        // === KOORDINATALAR (yuqori o'rta) ===
        if (cfg.showCoords) renderCoords(ctx, font, player, W);

        // === ARMOR (hayot paneli ostida) ===
        if (cfg.showArmor) renderArmor(ctx, font, player, cfg, W, H);

        // === CUSTOM CROSSHAIR ===
        if (cfg.customCrosshair) renderCrosshair(ctx, cfg, W, H, player);

        // === EFFECTLAR ===
        if (cfg.showEffects) renderEffects(ctx, font, player, W);
    }

    // ── HEALTH ──────────────────────────────────────────────────────────────
    private void renderHealth(DrawContext ctx, TextRenderer font,
                               ClientPlayerEntity player, SinsataConfig cfg,
                               int W, int H) {
        float hp = player.getHealth();
        float maxHp = player.getMaxHealth();
        float pct = maxHp > 0 ? hp / maxHp : 0;

        // Animatsiyali rang
        int color;
        if (pct > 0.6f)      color = 0xFF44FF88;
        else if (pct > 0.3f) color = 0xFFFFAA00;
        else                  color = 0xFFFF4444;

        // Panel joylashuvi
        int pX = cfg.healthOnLeft ? 4 : W - 84;
        int pY = H - 52;
        int pW = 80, pH = 24;

        // Fon (Night DLC: qora shisha)
        ctx.fill(pX, pY, pX + pW, pY + pH, 0xCC0A0A0E);
        // Chap aksent chiziq
        ctx.fill(pX, pY, pX + 2, pY + pH, color);
        // Yuqori ingichka chiziq
        ctx.fill(pX + 2, pY, pX + pW, pY + 1, 0x44FFFFFF);

        // HP bar fon
        int bX = pX + 6, bY = pY + 4, bW = pW - 12, bH = 5;
        ctx.fill(bX, bY, bX + bW, bY + bH, 0x33FFFFFF);
        // HP bar fill
        int fillW = (int)(bW * pct);
        if (fillW > 0) ctx.fill(bX, bY, bX + fillW, bY + bH, color);
        // Gradient overlay
        ctx.fillGradient(bX, bY, bX + fillW, bY + bH, color | 0xFF000000, (color & 0xFFFFFF) | 0xBB000000);

        // Matn: "❤ 18.5 / 20"
        String hpStr = "\u2665 " + String.format("%.1f", hp) + " / " + (int)maxHp;
        ctx.drawText(font, hpStr, pX + 6, pY + 13, color, true);
    }

    // ── FPS + PING ──────────────────────────────────────────────────────────
    private void renderInfoTopRight(DrawContext ctx, TextRenderer font,
                                     ClientPlayerEntity player, SinsataConfig cfg, int W) {
        int x = W - 4;
        int y = 4;

        if (cfg.showFps) {
            int fps = MinecraftClient.getCurrentFps();
            int fc = fps >= 100 ? 0xFF44FF88 : fps >= 60 ? 0xFFFFAA00 : 0xFFFF4444;
            String s = fps + " FPS";
            renderTag(ctx, font, s, x - font.getWidth(s) - 2, y, fc);
            y += 13;
        }

        if (cfg.showPing) {
            int ping = 0;
            var nh = mc.getNetworkHandler();
            if (nh != null) {
                PlayerListEntry e = nh.getPlayerListEntry(player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            int pc = ping < 60 ? 0xFF44FF88 : ping < 150 ? 0xFFFFAA00 : 0xFFFF4444;
            String s = ping + " ms";
            renderTag(ctx, font, s, x - font.getWidth(s) - 2, y, pc);
        }
    }

    // Night DLC uslubida kichik tag
    private void renderTag(DrawContext ctx, TextRenderer font, String text, int x, int y, int color) {
        int w = font.getWidth(text) + 6;
        ctx.fill(x - 1, y - 1, x + w + 1, y + 10, 0xAA0A0A0E);
        ctx.fill(x - 1, y - 1, x, y + 10, color);
        ctx.drawText(font, text, x + 3, y, color, false);
    }

    // ── KOORDINATALAR ───────────────────────────────────────────────────────
    private void renderCoords(DrawContext ctx, TextRenderer font,
                               ClientPlayerEntity player, int W) {
        String coords = String.format("X: %d  Y: %d  Z: %d",
                (int)player.getX(), (int)player.getY(), (int)player.getZ());
        int cx = W / 2 - font.getWidth(coords) / 2;
        ctx.fill(cx - 4, 2, cx + font.getWidth(coords) + 4, 14, 0xAA0A0A0E);
        ctx.drawText(font, coords, cx, 4, 0xAAAAEEFF, false);
    }

    // ── ARMOR ───────────────────────────────────────────────────────────────
    private void renderArmor(DrawContext ctx, TextRenderer font,
                              ClientPlayerEntity player, SinsataConfig cfg, int W, int H) {
        int armor = player.getArmor();
        if (armor <= 0) return;
        int pX = cfg.healthOnLeft ? 4 : W - 84;
        int pY = H - 26;
        String s = "\u26E1 " + armor;
        ctx.drawText(font, s, pX + 6, pY, 0xFF8899AA, true);
    }

    // ── CROSSHAIR ───────────────────────────────────────────────────────────
    private void renderCrosshair(DrawContext ctx, SinsataConfig cfg,
                                  int W, int H, ClientPlayerEntity player) {
        int cx = W / 2, cy = H / 2;
        int color = 0xFF000000 | cfg.crosshairColor;
        int sz = cfg.crosshairSize;
        int th = cfg.crosshairThickness;

        switch (cfg.crosshairType) {
            case 0 -> {
                // Krest
                ctx.fill(cx - sz, cy - th/2, cx + sz, cy + th/2 + 1, color);
                ctx.fill(cx - th/2, cy - sz, cx + th/2 + 1, cy + sz, color);
            }
            case 1 -> {
                // Nuqta
                ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, color);
            }
            case 2 -> {
                // Doira (polygon approximation)
                drawCircle(ctx, cx, cy, sz, th, color);
            }
            case 3 -> {
                // T-shakl
                ctx.fill(cx - sz, cy - th/2, cx + sz, cy + th/2 + 1, color);
                ctx.fill(cx - th/2, cy, cx + th/2 + 1, cy + sz, color);
            }
        }

        // Sakrash doirasi
        if (cfg.showJumpCircle && player.isOnGround()) {
            drawCircle(ctx, cx, cy, sz + 7, 1, color & 0x66FFFFFF);
        }
    }

    private void drawCircle(DrawContext ctx, int cx, int cy, int r, int th, int color) {
        int steps = 36;
        for (int i = 0; i < steps; i++) {
            double a1 = 2 * Math.PI * i / steps;
            double a2 = 2 * Math.PI * (i+1) / steps;
            int x1 = cx + (int)(Math.cos(a1)*r);
            int y1 = cy + (int)(Math.sin(a1)*r);
            int x2 = cx + (int)(Math.cos(a2)*r);
            int y2 = cy + (int)(Math.sin(a2)*r);
            ctx.fill(Math.min(x1,x2), Math.min(y1,y2),
                     Math.max(x1,x2)+th, Math.max(y1,y2)+th, color);
        }
    }

    // ── EFFECTLAR ───────────────────────────────────────────────────────────
    private void renderEffects(DrawContext ctx, TextRenderer font,
                                ClientPlayerEntity player, int W) {
        var effects = player.getStatusEffects();
        if (effects.isEmpty()) return;

        int ex = W - 4;
        int ey = 60;
        for (var effect : effects) {
            int duration = effect.getDuration();
            String dStr = duration > 1200
                ? "∞"
                : String.format("%d:%02d", duration/1200, (duration%1200)/20);
            String name = effect.getEffectType().getName().getString();
            String line = name + " " + dStr;
            int color = effect.getEffectType().getColor() | 0xFF000000;
            renderTag(ctx, font, line, ex - font.getWidth(line) - 4, ey, color);
            ey += 13;
        }
    }
}
